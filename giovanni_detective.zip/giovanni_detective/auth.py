"""Credenciais do Earthdata Login (EDL).

Ordem de busca: variáveis de ambiente / .env  ->  ~/.netrc  ->  prompt (--interactive).
Nada é gravado em disco nem impresso em log.
"""
from __future__ import annotations

import getpass
import logging
import netrc
import os
import sys
from dataclasses import dataclass

import requests

log = logging.getLogger(__name__)

URS_HOST = "urs.earthdata.nasa.gov"
TOKEN_URL = f"https://{URS_HOST}/api/users/find_or_create_token"


class MissingCredentials(RuntimeError):
    pass


@dataclass
class UserPass:
    username: str
    password: str


class Earthdata:
    def __init__(self, session: requests.Session, interactive: bool = False):
        self.session = session
        self.interactive = interactive and sys.stdin.isatty()
        self._token: str | None = None
        self._userpass: UserPass | None = None

    def userpass(self) -> UserPass | None:
        if self._userpass:
            return self._userpass
        u, p = os.getenv("EARTHDATA_USERNAME"), os.getenv("EARTHDATA_PASSWORD")
        if u and p:
            self._userpass = UserPass(u, p)
        else:
            try:
                auth = netrc.netrc().authenticators(URS_HOST)
                if auth and auth[0] and auth[2]:
                    self._userpass = UserPass(auth[0], auth[2])
            except (FileNotFoundError, netrc.NetrcParseError):
                pass
        if not self._userpass and self.interactive:
            user = input("Earthdata usuário: ").strip()
            pwd = getpass.getpass("Earthdata senha: ")
            if user and pwd:
                self._userpass = UserPass(user, pwd)
        return self._userpass

    def token(self) -> str:
        if self._token:
            return self._token
        token = os.getenv("EARTHDATA_TOKEN")
        if not token:
            creds = self.userpass()
            if not creds:
                raise MissingCredentials(
                    "Defina EARTHDATA_USERNAME/EARTHDATA_PASSWORD (ou EARTHDATA_TOKEN) no .env, "
                    f"ou ~/.netrc (machine {URS_HOST}). Conta gratuita: https://{URS_HOST}/users/new")
            r = self.session.post(TOKEN_URL, auth=(creds.username, creds.password), timeout=60)
            if r.status_code == 401:
                raise MissingCredentials("Earthdata Login recusou usuário/senha (HTTP 401).")
            r.raise_for_status()
            token = r.json()["access_token"]
            log.info("Earthdata: token obtido (expira em %s)", r.json().get("expiration_date", "?"))
        self._token = token
        return token
