"""Catálogo de variáveis do Giovanni (público, sem login).

* Busca (Solr):  https://giovanni.gsfc.nasa.gov/giovanni/daac-bin/catalogServices.pl
* Variáveis aceitas pelo serviço de séries temporais na nuvem:
                 https://api.giovanni.earthdata.nasa.gov/configured-variables
* ID da coleção (para o Harmony): NASA CMR, por short_name + versão.
Formatos conferidos ao vivo em nov/2026.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, asdict
from datetime import date, datetime

import requests

log = logging.getLogger(__name__)

SOLR = "https://giovanni.gsfc.nasa.gov/giovanni/daac-bin/catalogServices.pl"
CONFIGURED = "https://api.giovanni.earthdata.nasa.gov/configured-variables"
CMR = "https://cmr.earthdata.nasa.gov/search/collections.umm_json"

INTERVAL_HOURS = {"half-hourly": 0.5, "hourly": 1, "3-hourly": 3, "daily": 24, "weekly": 168,
                  "8-daily": 192, "monthly": 730}


# O servidor do catálogo deixou sem resposta um cliente Python com User-Agent próprio, enquanto a mesma
# consulta responde em ~2 s no navegador. Por isso esta consulta se identifica como navegador, falha
# rápido (sem novas tentativas) e tem alternativa: os dados essenciais saem do próprio ID da variável.
BROWSER_HEADERS = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0",
                   "Accept": "application/json, text/plain, */*"}
SOLR_TIMEOUT = (10, 30)


class CatalogUnavailable(RuntimeError):
    pass


def split_id(var_id: str) -> tuple[str, str, str]:
    """'GLDAS_NOAH025_M_2_1_Tair_f_inst' -> ('GLDAS_NOAH025_M', '2.1', 'Tair_f_inst')."""
    m = re.match(r"^(.+?)_(\d+(?:_\d+)*)_([A-Za-z].*)$", var_id)
    if not m:
        raise ValueError(f"ID fora do padrão <coleção>_<versão>_<variável>: {var_id}")
    return m.group(1), m.group(2).replace("_", "."), m.group(3)


def guess_interval(short_name: str) -> str:
    """Intervalo pelo nome do produto (só usado quando o catálogo não responde)."""
    n = short_name.upper()
    if re.search(r"(^M2[TI]M|_M$|STM$|IMERGM$|3B43$)", n):
        return "monthly"
    if n.endswith("_3H"):
        return "3-hourly"
    if re.search(r"IMERGHH", n):
        return "half-hourly"
    if re.search(r"(_7D$)", n):
        return "weekly"
    if re.search(r"(_D$|DAY|DAILY|STD$|IMERGD|D$|E$)", n) and not n.startswith("M2"):
        return "daily"
    return "hourly"   # desconhecido: assume o mais fino (blocos menores, sempre seguro)


def from_id(var_id: str) -> "Variable":
    short, version, name = split_id(var_id)
    return Variable(id=var_id, short_name=short, version=version, name=name, long_name="", units="",
                    interval=guess_interval(short), begin=None, end=None, west=-180, south=-90, east=180,
                    north=90, resolution="", accumulatable=False)


@dataclass
class Variable:
    id: str
    short_name: str
    version: str
    name: str
    long_name: str
    units: str
    interval: str
    begin: date | None
    end: date | None
    west: float
    south: float
    east: float
    north: float
    resolution: str
    accumulatable: bool

    @property
    def interval_hours(self) -> float:
        return INTERVAL_HOURS.get(self.interval.lower(), 24)

    def covers(self, lat: float, lon: float) -> bool:
        return self.south <= lat <= self.north and self.west <= lon <= self.east

    def row(self) -> dict:
        return asdict(self)


def _d(text: str | None) -> date | None:
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date() if text else None
    except ValueError:
        return None


def from_doc(doc: dict) -> Variable:
    return Variable(
        id=doc.get("dataFieldId", ""), short_name=doc.get("dataProductShortName", ""),
        version=str(doc.get("dataProductVersion", "")), name=doc.get("dataFieldAccessName", ""),
        long_name=doc.get("dataFieldLongName", ""), units=doc.get("dataFieldUnits", ""),
        interval=doc.get("dataProductTimeInterval", ""),
        begin=_d(doc.get("dataProductBeginDateTime")), end=_d(doc.get("dataProductEndDateTime")),
        west=float(doc.get("dataProductWest", -180)), south=float(doc.get("dataProductSouth", -90)),
        east=float(doc.get("dataProductEast", 180)), north=float(doc.get("dataProductNorth", 90)),
        resolution=doc.get("dataProductSpatialResolution", ""),
        accumulatable=bool(doc.get("dataFieldAccumulatable", False)),
    )


class Catalog:
    def __init__(self, session: requests.Session):
        self.session = session
        self._configured: set[str] | None = None
        self.degraded = False
        self._concepts: dict[tuple[str, str], str] = {}

    def configured(self) -> set[str]:
        if self._configured is None:
            r = self.session.get(CONFIGURED, timeout=(15, 60))
            r.raise_for_status()
            self._configured = set(r.json().get("configured_variables", []))
        return self._configured

    def _query(self, q: str, rows: int) -> list[Variable]:
        try:
            # requests.get direto: sem a política de novas tentativas da sessão (falha em 30 s, não em minutos)
            r = requests.get(SOLR, params={"version": "2.2", "wt": "json", "rows": rows, "start": 0,
                                           "q": q, "q.op": "AND"}, headers=BROWSER_HEADERS, timeout=SOLR_TIMEOUT)
            r.raise_for_status()
            return [from_doc(d) for d in r.json().get("response", {}).get("docs", [])]
        except (requests.RequestException, ValueError) as e:
            raise CatalogUnavailable(f"catálogo do Giovanni não respondeu ({type(e).__name__})") from e

    def search(self, text: str = "", interval: str | None = None, rows: int = 500,
               only_configured: bool = True) -> list[Variable]:
        q = "dataFieldActive:true"
        if text:
            q += f" AND dataFieldKeywordsText:({text})"
        if interval:
            q += f' AND dataProductTimeInterval:"{interval}"'
        found = self._query(q, rows)
        if only_configured:
            ok = self.configured()
            found = [v for v in found if v.id in ok]
        return sorted(found, key=lambda v: v.id)

    def search_ids(self, text: str = "", interval: str | None = None) -> list[Variable]:
        """Alternativa sem o catálogo: filtra a lista de variáveis habilitadas pelo texto do ID."""
        words = [w.lower() for w in text.split()]
        out = []
        for vid in sorted(self.configured()):
            try:
                v = from_id(vid)
            except ValueError:
                continue
            if all(w in vid.lower() for w in words) and (not interval or v.interval == interval.lower()):
                out.append(v)
        return out

    def get(self, ids: list[str]) -> dict[str, Variable]:
        """Metadados das variáveis. Se o catálogo não responder, deduz o essencial do próprio ID."""
        if not ids:
            return {}
        q = "(" + " OR ".join(f'dataFieldId:"{i}"' for i in ids) + ") AND dataFieldActive:true"
        try:
            return {v.id: v for v in self._query(q, len(ids))}
        except CatalogUnavailable as e:
            log.warning("%s; seguindo com dados deduzidos do ID (sem descrição, unidade e cobertura)", e)
            self.degraded = True
            out = {}
            for i in ids:
                try:
                    out[i] = from_id(i)
                except ValueError:
                    pass
            return out

    def concept_id(self, var: Variable) -> str:
        key = (var.short_name, var.version)
        if key not in self._concepts:
            for params in ({"short_name": var.short_name, "version": var.version}, {"short_name": var.short_name}):
                r = self.session.get(CMR, params={**params, "page_size": 5}, timeout=(15, 60))
                r.raise_for_status()
                items = r.json().get("items", [])
                if items:
                    self._concepts[key] = items[0]["meta"]["concept-id"]
                    break
            else:
                raise ValueError(f"Coleção {var.short_name} v{var.version} não encontrada no CMR")
        return self._concepts[key]
