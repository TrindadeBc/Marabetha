"""Linha de comando.

  python -m giovanni_detective search precipitation --interval monthly
  python -m giovanni_detective run --lat -23.55 --lon -46.63 --start 2001-01-01 --end 2024-12-31
  python -m giovanni_detective run --bbox -47.2,-24.1,-46.0,-23.0 --var GPM_3IMERGM_07_precipitation
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
from datetime import date
from pathlib import Path

import pandas as pd

from .analysis.profiler import profile_series
from .auth import Earthdata, MissingCredentials
from .catalog import Catalog, CatalogUnavailable
from .harmony import HarmonyClient, Location
from .http import build_session
from .report import md_table, write

log = logging.getLogger("giovanni_detective")

PRESETS = {
    # mensal: séries curtas (1 ponto/mês) — o melhor ponto de partida para tendência
    "mensal": ("GLDAS_NOAH025_M_2_1_Tair_f_inst", "GLDAS_NOAH025_M_2_1_Rainf_f_tavg",
               "GLDAS_NOAH025_M_2_1_Evap_tavg", "GLDAS_NOAH025_M_2_1_SoilMoi0_10cm_inst",
               "GLDAS_NOAH025_M_2_1_Qs_acc", "GPM_3IMERGM_07_precipitation"),
    # 3h: mesma física em alta resolução (extremos, ciclo diurno); pedidos bem maiores
    "3h": ("GLDAS_NOAH025_3H_2_1_Tair_f_inst", "GLDAS_NOAH025_3H_2_1_Rainf_f_tavg",
           "GLDAS_NOAH025_3H_2_1_Evap_tavg", "GLDAS_NOAH025_3H_2_1_SoilMoi0_10cm_inst"),
}


def parse_dotenv(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in text.lstrip("﻿").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip().removeprefix("export ").strip()
        v = v.strip()
        if v[:1] in "\"'" and len(v) >= 2 and v[-1] == v[0]:
            v = v[1:-1]
        elif " #" in v:
            v = v.split(" #", 1)[0].rstrip()
        if k:
            out[k] = v
    return out


def load_dotenv(path: Path) -> None:
    """Carrega o .env; mostra só os NOMES das chaves, nunca os valores."""
    path = path.resolve()
    if not path.exists():
        log.info("Sem arquivo %s (credenciais só do ambiente ou ~/.netrc)", path)
        return
    loaded = []
    for k, v in parse_dotenv(path.read_text(encoding="utf-8", errors="replace")).items():
        if v:
            if not os.environ.get(k):
                os.environ[k] = v
            loaded.append(k)
    log.info(".env lido de %s — chaves com valor: %s", path, ", ".join(loaded) or "nenhuma")


def cmd_search(args) -> int:
    cat = Catalog(build_session())
    try:
        found = cat.search(args.text or "", interval=args.interval, only_configured=not args.all)
    except CatalogUnavailable as e:
        print(f"Aviso: {e}. Mostrando as variáveis habilitadas cujo ID contém o texto buscado "
              "(sem descrição e unidade; a busca é pelo nome técnico, ex.: Rainf, Tair, precipitation).\n")
        found = cat.search_ids(args.text or "", interval=args.interval)
    if args.lat is not None and args.lon is not None:
        found = [v for v in found if v.covers(args.lat, args.lon)]
    df = pd.DataFrame([{"id": v.id, "descrição": v.long_name[:70], "unidade": v.units, "intervalo": v.interval,
                        "início": v.begin, "fim": v.end, "resolução": v.resolution} for v in found])
    print(md_table(df.head(args.limit)) if not df.empty else "Nenhuma variável encontrada.")
    print(f"{len(df)} variável(is)" + (f"; mostrando {args.limit}" if len(df) > args.limit else ""))
    if args.csv:
        pd.DataFrame([v.row() for v in found]).to_csv(args.csv, index=False)
        print(f"Lista completa em {args.csv}")
    return 0


def cmd_run(args) -> int:
    if args.bbox:
        try:
            w, s, e, n = (float(x) for x in args.bbox.split(","))
        except ValueError:
            print("--bbox deve ser W,S,E,N (ex.: -47.2,-24.1,-46.0,-23.0)", file=sys.stderr)
            return 2
        if not (w < e and s < n):
            print("--bbox inválido: precisa de W < E e S < N", file=sys.stderr)
            return 2
        loc = Location(bbox=(w, s, e, n))
        lat, lon = (s + n) / 2, (w + e) / 2
    else:
        loc = Location(lat=args.lat, lon=args.lon)
        lat, lon = args.lat, args.lon
    if args.start >= args.end:
        print("--start deve ser anterior a --end", file=sys.stderr)
        return 2

    ids = [v.strip() for item in args.var for v in item.split(",") if v.strip()] or list(PRESETS[args.preset])
    out: Path = args.out
    (out / "data").mkdir(parents=True, exist_ok=True)
    raw = out / "raw"
    raw.mkdir(exist_ok=True)

    session = build_session()
    edl = Earthdata(session, interactive=args.interactive)
    try:
        edl.token()
    except MissingCredentials as e:
        print(f"Login: {e}", file=sys.stderr)
        return 1

    cat = Catalog(session)
    known = cat.get(ids)
    configured = cat.configured()
    client = HarmonyClient(session, edl)
    profiles, failures, notes, long_names = [], {}, [], {}

    for vid in ids:
        var = known.get(vid)
        if var is None:
            failures[vid] = "não existe no catálogo do Giovanni (use o comando 'search' para achar o ID)"
            continue
        if cat.degraded and "catálogo" not in " ".join(notes):
            notes.append("O catálogo do Giovanni não respondeu: descrição, unidade e cobertura das variáveis "
                         "não foram conferidas antes do pedido.")
        if vid not in configured:
            failures[vid] = "existe no catálogo, mas não está habilitada no serviço de séries temporais"
            continue
        if not var.covers(lat, lon):
            failures[vid] = (f"local fora da cobertura do produto "
                             f"(lat {var.south}…{var.north}, lon {var.west}…{var.east})")
            continue
        t0 = max(args.start, var.begin) if var.begin else args.start
        t1 = min(args.end, var.end) if var.end else args.end
        if t0 > t1:
            failures[vid] = f"sem dados no período (produto cobre {var.begin} → {var.end})"
            continue
        if (t0, t1) != (args.start, args.end):
            notes.append(f"{vid}: período ajustado para {t0} → {t1} (cobertura do produto)")
        log.info("==> %s — %s [%s, %s]", vid, var.long_name, var.units, var.interval)
        try:
            meta, s = client.series(cat.concept_id(var), var, loc, t0, t1, raw)
        except PermissionError as e:
            print(f"\nAcesso negado: {e}", file=sys.stderr)
            return 1
        except Exception as e:  # uma variável com problema não derruba as outras
            log.warning("%s falhou: %s", vid, e)
            failures[vid] = str(e)[:400]
            continue
        s.to_frame(vid).to_csv(out / "data" / f"{vid}.csv", index_label="time")
        long_names[vid] = var.long_name
        profiles.append(profile_series(s, "giovanni", f"{var.short_name} v{var.version}",
                                       meta.get("unit") or meta.get("units") or var.units))
        log.info("  %s: %d valores salvos", vid, s.notna().sum())

    path = write(out, loc.label(), args.start, args.end, profiles, long_names, failures, notes)
    ready = sum(p.suitability.startswith("Pronta") for p in profiles)
    print(f"\nRelatório: {path}")
    print(f"  {len(profiles)} de {len(ids)} variável(is) obtida(s); {ready} pronta(s) para análise de tendência.")
    for k, v in failures.items():
        print(f"  [FALHOU] {k}: {v[:160]}")
    return 0 if profiles else 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="giovanni_detective",
                                description="Séries temporais do NASA Giovanni (via Harmony) + análise de tendência.")
    p.add_argument("--env-file", type=Path, default=Path(".env"))
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("search", help="procura variáveis no catálogo do Giovanni (sem login)")
    s.add_argument("text", nargs="?", help="palavra-chave em inglês (ex.: precipitation, temperature, soil moisture)")
    s.add_argument("--interval", help="monthly, daily, hourly, 3-hourly, half-hourly…")
    s.add_argument("--lat", type=float)
    s.add_argument("--lon", type=float)
    s.add_argument("--all", action="store_true", help="inclui variáveis não habilitadas para séries temporais")
    s.add_argument("--limit", type=int, default=40)
    s.add_argument("--csv", type=Path, help="salva a lista completa neste CSV")
    s.set_defaults(func=cmd_search)

    r = sub.add_parser("run", help="baixa as séries e gera o relatório (exige Earthdata Login)")
    r.add_argument("--lat", type=float, default=-23.55, help="latitude do ponto (padrão: São Paulo)")
    r.add_argument("--lon", type=float, default=-46.63)
    r.add_argument("--bbox", help="W,S,E,N — em vez do ponto, calcula a média da área")
    r.add_argument("--start", type=date.fromisoformat, default=date(2001, 1, 1))
    r.add_argument("--end", type=date.fromisoformat, default=date(2024, 12, 31))
    r.add_argument("--var", action="append", default=[], help="ID Giovanni; repetível ou separado por vírgula")
    r.add_argument("--preset", choices=sorted(PRESETS), default="mensal", help="usado quando não há --var")
    r.add_argument("--out", type=Path, default=Path("saida"))
    r.add_argument("--interactive", action="store_true", help="pede usuário/senha no terminal se faltar")
    r.set_defaults(func=cmd_run)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s", datefmt="%H:%M:%S")
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    load_dotenv(args.env_file)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
