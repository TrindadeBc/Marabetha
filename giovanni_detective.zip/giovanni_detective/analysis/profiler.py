"""Diz, para cada série obtida, se e como ela pode ser tratada e analisada.

Para séries temporais:
  1. infere a resolução nativa (mediana dos intervalos)
  2. agrega para mensal e mede completude, extensão e sazonalidade
  3. remove o ciclo sazonal (anomalia mensal) e roda Mann-Kendall + Sen
  4. classifica a aptidão para detecção de tendência e sugere o tratamento
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

import numpy as np
import pandas as pd

from .trend import decimal_years, mann_kendall

# Limiares de aptidão (ajustáveis). Referência usual em climatologia: ≥30 anos
# para normais; para tendência em hackathon, 10 anos completos já é defensável.
READY_YEARS, READY_COMPLETENESS, READY_MONTHS = 10.0, 0.80, 60
CAUTION_YEARS, CAUTION_COMPLETENESS = 5.0, 0.60

SKIP_COLS = ("lat", "lon", "latitude", "longitude", "elevation", "id", "objectid", "fid", "qa", "quality",
             "x", "y", "_x", "_y", "orbit", "pass", "row_num")
DATE_HINTS = ("date", "time", "year", "année", "annee", "datetime", "timestamp", "periode", "period")
ACCUMULATED_HINTS = ("prcp", "rain", "precip", "snow", "qs_", "qsb", "evap", "runoff")


@dataclass
class VariableProfile:
    source: str
    dataset: str
    variable: str
    units: str = ""
    kind: str = ""
    dtype: str = ""
    n_obs: int = 0
    start: str = ""
    end: str = ""
    span_years: float = 0.0
    native_resolution: str = ""
    completeness: float = float("nan")
    missing_pct: float = float("nan")
    mean: float = float("nan")
    std: float = float("nan")
    min: float = float("nan")
    max: float = float("nan")
    seasonality_acf12: float = float("nan")
    mk_tau: float = float("nan")
    mk_p_value: float = float("nan")
    sen_slope_per_decade: float = float("nan")
    lag1_autocorr: float = float("nan")
    trend: str = ""
    suitability: str = ""
    suggested_treatment: list[str] = field(default_factory=list)

    def row(self) -> dict:
        d = asdict(self)
        d["suggested_treatment"] = " | ".join(self.suggested_treatment)
        return d


def _resolution(idx: pd.DatetimeIndex) -> str:
    if len(idx) < 3:
        return "indeterminada"
    d = pd.Series(idx.sort_values()).diff().dropna().median()
    hours = d / pd.Timedelta(hours=1)
    for limit, label in ((1.5, "horária"), (4, "3-horária"), (36, "diária"), (12 * 24, "semanal/8–16 dias"),
                         (40 * 24, "mensal"), (100 * 24, "sazonal/trimestral"), (400 * 24, "anual")):
        if hours <= limit:
            return label
    return "irregular/plurianual"


def _is_skip(col: str) -> bool:
    c = col.lower()
    return any(c == s or c.endswith("_" + s) or c.startswith(s + "_") for s in SKIP_COLS)


def profile_series(s: pd.Series, source: str, dataset: str, units: str = "") -> VariableProfile:
    s = pd.to_numeric(s, errors="coerce")
    s.index = pd.DatetimeIndex(s.index)
    s = s[~s.index.isna()].sort_index()
    p = VariableProfile(source, dataset, str(s.name), units, "série temporal", str(s.dtype))
    valid = s.dropna()
    p.n_obs = int(valid.size)
    p.missing_pct = round(100 * (1 - valid.size / max(len(s), 1)), 1)
    if valid.empty:
        p.suitability = "Sem dados válidos"
        p.suggested_treatment = ["verificar valores de preenchimento (fill/_FillValue) e o período pedido"]
        return p

    p.start, p.end = f"{valid.index[0]:%Y-%m-%d}", f"{valid.index[-1]:%Y-%m-%d}"
    p.span_years = round((valid.index[-1] - valid.index[0]).days / 365.25, 2)
    p.native_resolution = _resolution(valid.index)
    p.mean, p.std = float(valid.mean()), float(valid.std())
    p.min, p.max = float(valid.min()), float(valid.max())
    tips: list[str] = []

    if p.std == 0 or valid.nunique() <= 1:
        p.suitability = "Constante — não analisável"
        p.suggested_treatment = ["variável sem variação no período; descartar ou checar a extração"]
        return p

    accumulated = any(h in p.variable.lower() for h in ACCUMULATED_HINTS)
    # Agrega na resolução de análise: mensal, ou a nativa se for mais grossa.
    freq, period, min_points = {"sazonal/trimestral": ("QS", "Q", 20),
                                "anual": ("YS", "Y", READY_YEARS),
                                "irregular/plurianual": ("YS", "Y", READY_YEARS)}.get(
        p.native_resolution, ("MS", "M", READY_MONTHS))
    monthly = valid.resample(freq).sum(min_count=1) if accumulated and p.native_resolution == "diária" \
        else valid.resample(freq).mean()
    expected = len(pd.date_range(valid.index[0].to_period(period).to_timestamp(),
                                 valid.index[-1].to_period(period).to_timestamp(), freq=freq))
    p.completeness = round(monthly.notna().sum() / max(expected, 1), 3)

    if freq == "MS" and monthly.notna().sum() >= 36:
        p.seasonality_acf12 = round(float(monthly.autocorr(lag=12)), 3)

    if freq == "MS" and monthly.notna().sum() >= 24:
        clim = monthly.groupby(monthly.index.month).transform("mean")
        anomaly = (monthly - clim).dropna()
        target = anomaly if anomaly.size >= 8 else monthly.dropna()
    else:
        agg = monthly.dropna()
        target = agg if agg.size >= 8 else (valid if valid.size >= 8 else None)

    if target is not None and target.size >= 8:
        if target.size > 2000:
            target = target.iloc[np.linspace(0, target.size - 1, 2000).astype(int)]
        mk = mann_kendall(decimal_years(target.index), target.to_numpy(dtype=float))
        p.mk_tau, p.mk_p_value = round(mk.tau, 4), round(mk.p_value, 5)
        p.sen_slope_per_decade = mk.sen_slope_per_year * 10
        p.lag1_autocorr = round(mk.lag1_autocorr, 3)
        p.trend = mk.direction

    n_points = int(monthly.notna().sum())
    if p.span_years >= READY_YEARS and p.completeness >= READY_COMPLETENESS and n_points >= min_points:
        p.suitability = "Pronta para análise de tendência"
    elif p.span_years >= CAUTION_YEARS and p.completeness >= CAUTION_COMPLETENESS:
        p.suitability = "Tendência com cautela (série curta ou com lacunas)"
    elif p.span_years >= 1:
        p.suitability = "Exploratória (sazonalidade, eventos, anomalias)"
    else:
        p.suitability = "Insuficiente para tendência"
        tips.append("ampliar o período pedido (--start/--end)")

    if p.native_resolution in ("horária", "3-horária", "diária"):
        tips.append("agregar para mensal/anual antes do teste (soma se acumulada, média se estado)")
    if not np.isnan(p.seasonality_acf12) and p.seasonality_acf12 > 0.3:
        tips.append("forte sazonalidade: usar anomalias mensais, STL ou Mann-Kendall sazonal")
    if not np.isnan(p.lag1_autocorr) and p.lag1_autocorr > 0.3:
        tips.append("autocorrelação alta: usar MK modificado (Hamed-Rao) ou pré-branqueamento (TFPW)")
    if p.completeness < READY_COMPLETENESS:
        tips.append("lacunas: interpolar só falhas curtas; não preencher meses longos")
    if accumulated or (p.min >= 0 and valid.skew() > 2):
        tips.append("distribuição assimétrica/zero-inflada: preferir testes não paramétricos e totais")
    if p.mk_p_value == p.mk_p_value and p.mk_p_value < 0.05:
        tips.append(f"tendência detectada ({p.trend}); confirmar com Pettitt/quebras e sensibilidade ao período")
    p.suggested_treatment = tips
    return p
