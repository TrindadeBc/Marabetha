"""Testes não paramétricos de tendência (sem dependências além de numpy/scipy).

* Mann-Kendall com correção de empates (Kendall 1975; Gilbert 1987)
* Estimador de declividade de Sen (Sen 1968)
* Autocorrelação lag-1, para avisar quando o MK clássico superestima a significância
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.stats import norm


@dataclass
class TrendResult:
    n: int
    s: float
    tau: float
    z: float
    p_value: float
    sen_slope_per_year: float
    lag1_autocorr: float

    @property
    def direction(self) -> str:
        if self.p_value >= 0.05:
            return "sem tendência significativa"
        return "aumento" if self.s > 0 else "redução"


def mann_kendall(t_years: np.ndarray, y: np.ndarray) -> TrendResult:
    mask = np.isfinite(y) & np.isfinite(t_years)
    t, y = t_years[mask], y[mask]
    n = len(y)
    if n < 8:
        raise ValueError("Mann-Kendall precisa de pelo menos 8 observações")

    iu = np.triu_indices(n, k=1)
    dy = y[iu[1]] - y[iu[0]]
    s = float(np.sign(dy).sum())

    _, counts = np.unique(y, return_counts=True)
    ties = counts[counts > 1]
    var_s = (n * (n - 1) * (2 * n + 5) - np.sum(ties * (ties - 1) * (2 * ties + 5))) / 18.0
    z = 0.0 if s == 0 else (s - np.sign(s)) / np.sqrt(var_s)
    p = float(2 * (1 - norm.cdf(abs(z))))
    tau = s / (0.5 * n * (n - 1))

    dt = t[iu[1]] - t[iu[0]]
    ok = dt != 0
    sen = float(np.median(dy[ok] / dt[ok])) if ok.any() else float("nan")

    yc = y - y.mean()
    denom = float(np.dot(yc, yc))
    r1 = float(np.dot(yc[:-1], yc[1:]) / denom) if denom > 0 else float("nan")
    return TrendResult(n, s, tau, float(z), p, sen, r1)


def decimal_years(index) -> np.ndarray:
    idx = index
    return (idx.year + (idx.dayofyear - 1) / 365.25 + idx.hour / 8766.0).to_numpy(dtype=float)
