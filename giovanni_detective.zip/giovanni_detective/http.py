"""Sessão HTTP e GET autenticado que sobrevive a redirecionamentos entre hosts."""
from __future__ import annotations

from urllib.parse import urljoin, urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .auth import URS_HOST, UserPass

USER_AGENT = "giovanni-trend-detective/1.0 (+NASA Space Apps 2026)"


def build_session(retries: int = 2) -> requests.Session:
    s = requests.Session()
    retry = Retry(total=retries, connect=retries, read=retries, status=retries, other=0, backoff_factor=1.0,
                  status_forcelist=(429, 502, 503, 504), allowed_methods=frozenset({"GET", "POST"}))
    s.mount("https://", HTTPAdapter(max_retries=retry))
    s.headers["User-Agent"] = USER_AGENT
    return s


def looks_like_html(text: str) -> bool:
    head = text.lstrip()[:200].lower()
    return head.startswith("<!doctype html") or head.startswith("<html")


def error_text(r: requests.Response) -> str:
    """Mensagem do servidor (o motivo real), não só o código."""
    try:
        j = r.json()
        msg = j.get("message") or j.get("description") or (j.get("errors") or [""])[0] or r.text
    except (ValueError, AttributeError):
        msg = r.text
    return f"HTTP {r.status_code}: {str(msg).strip()[:300]}"


def _is_nasa(host: str) -> bool:
    return host == "nasa.gov" or host.endswith(".nasa.gov")


def authed_get(session: requests.Session, url: str, token: str, userpass: UserPass | None = None,
               params=None, timeout=(15, 300), max_hops: int = 10) -> requests.Response:
    """GET seguindo redirecionamentos manualmente.

    O `requests` descarta o cabeçalho Authorization quando o redirecionamento muda de host;
    por isso um link de resultado pode cair na tela de login. Aqui, a cada salto:
      * host *.nasa.gov        -> envia o token Bearer
      * urs.earthdata.nasa.gov -> envia usuário/senha (fluxo padrão do Earthdata; o cookie fica na sessão)
      * outro host (ex.: S3)   -> sem credencial
    """
    for _ in range(max_hops):
        host = urlparse(url).hostname or ""
        headers, auth = {}, None
        if host == URS_HOST:
            if userpass:
                auth = (userpass.username, userpass.password)
        elif _is_nasa(host):
            headers["Authorization"] = f"Bearer {token}"
        r = session.get(url, params=params, headers=headers, auth=auth, allow_redirects=False, timeout=timeout)
        params = None
        if r.status_code in (301, 302, 303, 307, 308) and r.headers.get("Location"):
            url = urljoin(url, r.headers["Location"])
            continue
        return r
    raise RuntimeError(f"redirecionamentos demais ao acessar {urlparse(url).hostname}")
