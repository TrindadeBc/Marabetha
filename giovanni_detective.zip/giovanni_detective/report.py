"""Relatório Markdown e CSV do perfil das variáveis."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

from .analysis.profiler import VariableProfile


def _fmt(x) -> str:
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "–"
    if isinstance(x, float):
        return f"{x:.4g}"
    return str(x).replace("|", "/")


def md_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_(nenhuma)_\n"
    head = "| " + " | ".join(df.columns) + " |\n|" + "---|" * len(df.columns) + "\n"
    return head + "".join("| " + " | ".join(_fmt(v) for v in row) + " |\n" for row in df.itertuples(index=False))


def write(out: Path, where: str, start, end, profiles: list[VariableProfile], long_names: dict[str, str],
          failures: dict[str, str], notes: list[str]) -> Path:
    prof = pd.DataFrame([p.row() for p in profiles])
    prof.to_csv(out / "variaveis_analisadas.csv", index=False)
    L = ["# Giovanni Trend Detective — relatório\n",
         f"Gerado em {datetime.now():%Y-%m-%d %H:%M}. Local: **{where}**. Período pedido: **{start} → {end}**.\n"]
    if notes:
        L.append("## Avisos\n")
        L += [f"- {n}" for n in notes]
        L.append("")
    L.append("## Variáveis analisadas\n")
    L.append("Teste: Mann-Kendall sobre anomalias mensais (ciclo sazonal removido) + declividade de Sen. "
             "*Pronta* = pelo menos 10 anos e 80% dos meses com dado.\n")
    if not prof.empty:
        view = prof.copy()
        view["descrição"] = view["variable"].map(long_names).fillna("")
        view["p"] = view["mk_p_value"].map(lambda v: "–" if v != v else ("<0.0001" if v < 1e-4 else f"{v:.4f}"))
        cols = {"variable": "variável", "descrição": "descrição", "units": "unidade",
                "native_resolution": "resolução", "start": "início", "end": "fim", "span_years": "anos",
                "completeness": "completude", "suitability": "aptidão", "trend": "tendência", "p": "p (MK)",
                "sen_slope_per_decade": "Sen/década", "suggested_treatment": "tratamento sugerido"}
        L.append(md_table(view[list(cols)].rename(columns=cols)))
    else:
        L.append("_Nenhuma série foi obtida._\n")
    if failures:
        L.append("\n## Variáveis que falharam\n")
        L.append(md_table(pd.DataFrame([{"variável": k, "motivo": v} for k, v in failures.items()])))
    L.append("\n## Arquivos\n")
    L.append("- `data/<variável>.csv` — série limpa (índice = tempo UTC)\n"
             "- `raw/` — CSV original de cada job do Harmony (`raw/debug/` guarda respostas inesperadas)\n"
             "- `variaveis_analisadas.csv` — perfil e teste de tendência\n")
    path = out / "relatorio.md"
    path.write_text("\n".join(x.rstrip("\n") + "\n" for x in L), encoding="utf-8")
    return path
