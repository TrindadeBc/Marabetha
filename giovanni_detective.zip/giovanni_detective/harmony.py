"""Séries temporais do Giovanni pelo NASA Harmony.

O endpoint antigo api.giovanni.earthdata.nasa.gov/timeseries responde 500 (nov/2026).
O cliente oficial da NASA (github.com/nasa/terra-ui-components) faz:

  1. GET {HARMONY}/{coleção}/ogc-api-coverages/1.0.0/collections/parameter_vars/coverage/rangeset
         ?point=lon,lat                      (ponto)
         ou &subset=lat(S:N)&subset=lon(W:E)&average=area   (média de área)
         &subset=time("ini":"fim")&format=text/csv&variable=<ID Giovanni>
         &skipPreview=true&forceAsync=true                  -> {jobID, status}
  2. GET {HARMONY}/jobs/{jobID} até um status final
  3. baixa o link rel="data", trocando 'proxy-timeseries' por 'timeseries' e enviando o token
     (o link 'proxy-…' é para navegador e redireciona para a tela de login)
"""
from __future__ import annotations

import io
import logging
import re
import time
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import requests

from .auth import Earthdata
from .catalog import Variable
from .http import authed_get, error_text, looks_like_html

log = logging.getLogger(__name__)

HARMONY = "https://harmony.earthdata.nasa.gov"
MAX_POINTS = 150_000        # o serviço aceita até 200 mil pontos por pedido; margem de segurança
POLL_SECONDS = 3
JOB_TIMEOUT_MIN = 30
FINAL_OK = {"successful"}
FINAL_BAD = {"failed", "canceled", "complete_with_errors"}


class HarmonyError(RuntimeError):
    pass


ACCOUNT_HINT = ('O serviço de dados da GES DISC recusou esta conta (a mesma consulta funciona na ferramenta web). Causa mais provável: o app "NASA GESDISC DATA ARCHIVE" não está autorizado na conta Earthdata. Em https://urs.earthdata.nasa.gov > Applications > Authorized Apps > Approve More Applications, aprove "NASA GESDISC DATA ARCHIVE" e rode de novo.')


@dataclass(frozen=True)
class Location:
    """Ponto (lat, lon) ou caixa (west, south, east, north) para média de área."""
    lat: float | None = None
    lon: float | None = None
    bbox: tuple[float, float, float, float] | None = None

    @property
    def is_area(self) -> bool:
        return self.bbox is not None

    def label(self) -> str:
        if self.is_area:
            w, s, e, n = self.bbox
            return f"média de área W{w} S{s} E{e} N{n}"
        return f"ponto lat {self.lat}, lon {self.lon}"


def chunk_ranges(start: date, end: date, interval_hours: float, max_points: int = MAX_POINTS
                 ) -> list[tuple[date, date]]:
    days = max(1, int(max_points * interval_hours / 24))
    out, cur = [], start
    while cur <= end:
        stop = end if days >= (end - cur).days + 1 else cur + timedelta(days=days - 1)
        out.append((cur, stop))
        cur = stop + timedelta(days=1)
    return out


def build_params(var_id: str, loc: Location, t0: date, t1: date) -> list[tuple[str, str]]:
    p: list[tuple[str, str]] = []
    if loc.is_area:
        w, s, e, n = loc.bbox
        p += [("subset", f"lat({s}:{n})"), ("subset", f"lon({w}:{e})")]
    else:
        p.append(("point", f"{loc.lon},{loc.lat}"))          # Harmony usa lon,lat
    p += [("subset", f'time("{t0:%Y-%m-%d}T00:00:00.000Z":"{t1:%Y-%m-%d}T23:59:59.000Z")'),
          ("format", "text/csv"), ("label", "giovanni-trend-detective"), ("variable", var_id)]
    if loc.is_area:
        p.append(("average", "area"))
    p += [("skipPreview", "true"), ("forceAsync", "true")]
    return p


def parse_csv(text: str) -> tuple[dict[str, str], pd.Series]:
    """Metadados 'chave,valor' e depois linhas 'timestamp,valor' (cabeçalho 'Timestamp (UTC)' ou 'time')."""
    meta: dict[str, str] = {}
    times, values = [], []
    for line in io.StringIO(text):
        parts = [x.strip() for x in line.split(",")]
        if len(parts) < 2 or not parts[0]:
            continue
        if re.match(r"^\d{4}-\d{2}-\d{2}", parts[0]):
            ts = pd.to_datetime(parts[0], errors="coerce", utc=True)
            try:
                val = float(parts[1])
            except ValueError:
                val = float("nan")
            if pd.notna(ts):
                times.append(ts)
                values.append(val)
        elif not times and parts[0] not in ("time", "Timestamp (UTC)"):
            meta[parts[0]] = ",".join(parts[1:])
    if not times:
        raise HarmonyError("resultado sem linhas de dados. Início: " + text[:200].replace("\n", " | "))
    s = pd.Series(values, index=pd.DatetimeIndex(times).tz_convert(None), dtype=float)
    for key in ("undef", "fill_value", "_FillValue", "missing_value"):
        if key in meta:
            try:
                s = s.mask(s == float(meta[key]))
            except ValueError:
                pass
    return meta, s[~s.index.duplicated()].sort_index()


class HarmonyClient:
    def __init__(self, session: requests.Session, edl: Earthdata):
        self.session, self.edl = session, edl

    def _get(self, url: str, params=None, timeout=(15, 120)) -> requests.Response:
        return authed_get(self.session, url, self.edl.token(), self.edl.userpass(), params=params, timeout=timeout)

    def submit(self, concept_id: str, var_id: str, loc: Location, t0: date, t1: date) -> dict:
        url = f"{HARMONY}/{concept_id}/ogc-api-coverages/1.0.0/collections/parameter_vars/coverage/rangeset"
        r = self._get(url, params=build_params(var_id, loc, t0, t1))
        if r.status_code in (401, 403):
            raise PermissionError(f"Harmony recusou o acesso — {error_text(r)}. Confira a conta Earthdata e se o "
                                  "app 'NASA GESDISC DATA ARCHIVE' está autorizado no seu perfil.")
        if not r.ok:
            raise HarmonyError(f"pedido recusado — {error_text(r)}")
        job = r.json()
        if not job.get("jobID"):
            raise HarmonyError(f"resposta sem jobID: {r.text[:200]}")
        return job

    def wait(self, job: dict) -> dict:
        job_id = job["jobID"]
        deadline = time.time() + JOB_TIMEOUT_MIN * 60
        while job.get("status") not in FINAL_OK | FINAL_BAD:
            if time.time() > deadline:
                raise TimeoutError(f"job {job_id} ainda '{job.get('status')}' após {JOB_TIMEOUT_MIN} min "
                                   f"(acompanhe em {HARMONY}/jobs/{job_id})")
            time.sleep(POLL_SECONDS)
            r = self._get(f"{HARMONY}/jobs/{job_id}", timeout=(15, 60))
            if not r.ok:
                raise HarmonyError(f"erro ao consultar o job {job_id} — {error_text(r)}")
            job = r.json()
        if job["status"] in FINAL_BAD:
            errs = "; ".join(str(e.get("message", e)) for e in job.get("errors") or [])
            raise HarmonyError(f"job {job_id} terminou '{job['status']}' — {job.get('message', '')} {errs}".strip())
        return job

    def download(self, job: dict, debug_dir: Path | None = None) -> str:
        link = next((lk.get("href") for lk in job.get("links", []) if lk.get("rel") == "data"), None)
        if not link:
            raise HarmonyError(f"job {job.get('jobID')} sem link de dados")
        candidates = [link.replace("proxy-timeseries", "timeseries")]
        if candidates[0] != link:
            candidates.append(link)
        problems = []
        for url in candidates:
            r = self._get(url, timeout=(15, 300))
            where = url.split("?")[0]
            if r.status_code == 500 and '"message":null' in r.text.replace(" ", ""):
                raise PermissionError(ACCOUNT_HINT)
            if not r.ok:
                problems.append(f"{where} -> {error_text(r)}")
            elif looks_like_html(r.text):
                problems.append(f"{where} -> página HTML (pede login de navegador)")
                if debug_dir:
                    debug_dir.mkdir(parents=True, exist_ok=True)
                    (debug_dir / f"job-{job.get('jobID')}-resposta.html").write_text(r.text)
            else:
                return r.text
        raise HarmonyError("não foi possível baixar o resultado: " + " ; ".join(problems))

    def series(self, concept_id: str, var: Variable, loc: Location, start: date, end: date,
               raw_dir: Path) -> tuple[dict[str, str], pd.Series]:
        parts, meta = [], {}
        chunks = chunk_ranges(start, end, var.interval_hours)
        for i, (t0, t1) in enumerate(chunks):
            log.info("  %s: %s → %s (bloco %d/%d)", var.id, t0, t1, i + 1, len(chunks))
            job = self.submit(concept_id, var.id, loc, t0, t1)
            log.info("  %s: job %s criado; aguardando…", var.id, job["jobID"])
            text = self.download(self.wait(job), debug_dir=raw_dir / "debug")
            (raw_dir / f"{var.id}_{i:02d}.csv").write_text(text)
            m, s = parse_csv(text)
            meta = meta or m
            parts.append(s)
        s = pd.concat(parts)
        s = s[~s.index.duplicated()].sort_index()
        s.name = var.id
        return meta, s
