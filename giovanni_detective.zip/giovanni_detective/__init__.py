"""Giovanni Trend Detective — séries temporais do NASA Giovanni (via Harmony) e análise de tendência."""
__version__ = "1.0.0"
